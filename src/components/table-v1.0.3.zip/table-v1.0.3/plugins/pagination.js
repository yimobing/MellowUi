/**
 * MelUi Table 表格组件 - 分页插件
 * 底部分页栏，支持数字列表和下拉选择两种模式
 * 兼容性：IE9 / IE10 / IE11 / Edge
 * @Version：v1.0.0
 * @Date：2026-10-10
 * @Pubdate：2026-10-10
 */

 (function(MelUi) {

    /**
     * Pagination 分页插件
     * @param {Object} options 配置
     *   pageSize: 每页条数，默认30
     *   pageMode: 分页模式 'list' 数字列表 / 'select' 下拉选择，默认'list'
     *   pageListSize: 数字列表模式显示几个页码，默认5
     *   total: 总记录数（可选，不传则用当前数据长度）
     */
    function Pagination(options) {
        this.options = this._extend({
            pageSize: 30,
            pageMode: 'list',
            pageListSize: 5,
            total: 0
        }, options || {});

        this.curpage = 1;
    }

    Pagination.prototype = new MelUi.Table.PluginBase();
    Pagination.prototype.constructor = Pagination;

    /**
     * 初始化
     */
    Pagination.prototype.init = function(table) {
        this.table = table;
        this.total = this.options.total || table.dataStore.rows.length;

        this._renderBar();
        this._bindEvents();
    };

    /**
     * 渲染分页栏
     */
    Pagination.prototype._renderBar = function() {
        var totalPages = Math.ceil(this.total / this.options.pageSize) || 1;
        var self = this;

        var html = '<div class="mel-pagination">';
        html += '<span class="mel-page-info">共 ' + this.total + ' 条</span>';

        if (this.options.pageMode === 'select') {
            // 下拉选择模式
            html += '<select class="mel-page-select">';
            for (var i = 1; i <= totalPages; i++) {
                html += '<option value="' + i + '"' + (i === this.curpage ? ' selected' : '') + '>第 ' + i + ' 页</option>';
            }
            html += '</select>';
        } else {
            // 数字列表模式
            html += '<span class="mel-page-btn" data-action="first">首页</span>';
            html += '<span class="mel-page-btn" data-action="prev">上一页</span>';

            var start = Math.max(1, this.curpage - Math.floor(this.options.pageListSize / 2));
            var end = Math.min(totalPages, start + this.options.pageListSize - 1);
            start = Math.max(1, end - this.options.pageListSize + 1);

            for (var i = start; i <= end; i++) {
                html += '<span class="mel-page-num' + (i === this.curpage ? ' active' : '') + '" data-page="' + i + '">' + i + '</span>';
            }

            html += '<span class="mel-page-btn" data-action="next">下一页</span>';
            html += '<span class="mel-page-btn" data-action="last">尾页</span>';
        }

        html += '</div>';

        // 插入到表格容器后面
        var bar = document.createElement('div');
        bar.innerHTML = html;
        this.table.renderer.el.appendChild(bar.firstChild);
        this.barDom = this.table.renderer.el.querySelector('.mel-pagination');
    };

    /**
     * 绑定分页事件
     */
    Pagination.prototype._bindEvents = function() {
        var self = this;

        this.barDom.onclick = function(e) {
            var event = e || window.event;
            var target = event.target || event.srcElement;

            // 数字页码
            if (target.className.indexOf('mel-page-num') >= 0) {
                var page = parseInt(target.getAttribute('data-page'));
                self.goToPage(page);
                return;
            }

            // 按钮
            if (target.className.indexOf('mel-page-btn') >= 0) {
                var action = target.getAttribute('data-action');
                var totalPages = Math.ceil(self.total / self.options.pageSize) || 1;

                if (action === 'first') self.goToPage(1);
                if (action === 'prev') self.goToPage(self.curpage - 1);
                if (action === 'next') self.goToPage(self.curpage + 1);
                if (action === 'last') self.goToPage(totalPages);
            }
        };

        // 下拉选择模式
        var select = this.barDom.querySelector('.mel-page-select');
        if (select) {
            select.onchange = function() {
                self.goToPage(parseInt(this.value));
            };
        }
    };

    /**
     * 跳转到指定页
     * @param {Number} page 页码
     */
    Pagination.prototype.goToPage = function(page) {
        var totalPages = Math.ceil(this.total / this.options.pageSize) || 1;
        if (page < 1) page = 1;
        if (page > totalPages) page = totalPages;

        this.curpage = page;

        // 重新渲染分页栏
        this.barDom.parentNode.removeChild(this.barDom);
        this._renderBar();
        this._bindEvents();

        // 触发事件
        this.table.eventBus.emit('pageChange', {
            curpage: this.curpage,
            pagesize: this.options.pageSize
        });
    };

    /**
     * 更新总记录数
     * @param {Number} total 总记录数
     */
    Pagination.prototype.setTotal = function(total) {
        this.total = total;
        this.barDom.parentNode.removeChild(this.barDom);
        this._renderBar();
        this._bindEvents();
    };

    /**
     * 简单对象合并
     */
    Pagination.prototype._extend = function(target) {
        var sources = Array.prototype.slice.call(arguments, 1);
        for (var i = 0; i < sources.length; i++) {
            for (var key in sources[i]) {
                if (sources[i].hasOwnProperty(key)) {
                    target[key] = sources[i][key];
                }
            }
        }
        return target;
    };

    MelUi.Table = MelUi.Table || {};
    MelUi.Table.plugins = MelUi.Table.plugins || {};
    MelUi.Table.plugins.Pagination = Pagination;

})(window.MelUi = window.MelUi || {});
